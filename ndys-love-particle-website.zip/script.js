const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');
const heartBtn = document.getElementById('heartBtn');
const textBtn = document.getElementById('textBtn');
const secret = document.getElementById('secret');
const photoInput = document.getElementById('photoInput');
const photoFrame = document.getElementById('photoFrame');
const photo = document.getElementById('photo');
const removePhoto = document.getElementById('removePhoto');

let width, height, particles = [], target = [], mode = 'heart', burstUntil = 0;
const colors = ['#ff426f','#ff7794','#ffb0c0','#55f4cf','#fff0f4'];
const rand = (a,b) => Math.random()*(b-a)+a;

function resize(){
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  width = window.innerWidth; height = window.innerHeight;
  canvas.width = width*dpr; canvas.height = height*dpr;
  canvas.style.width = width+'px'; canvas.style.height = height+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
  buildTarget();
}
function heartPoint(t, scale){
  return {x:16*Math.pow(Math.sin(t),3)*scale,
    y:-(13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t))*scale};
}
function buildTarget(){
  target=[];
  const scale=Math.min(width,height)*0.017;
  const count=Math.min(900,Math.max(360,Math.floor(width*height/1600)));
  if(mode==='heart'){
    for(let i=0;i<count;i++){
      const t=Math.random()*Math.PI*2;
      const p=heartPoint(t,scale*rand(.75,1.05));
      target.push({x:width/2+p.x,y:height*.47+p.y});
    }
    // add a soft, filled particle heart
    for(let i=0;i<count*.5;i++){
      const t=Math.random()*Math.PI*2, r=Math.sqrt(Math.random());
      const p=heartPoint(t,scale*.92*r);
      target.push({x:width/2+p.x,y:height*.47+p.y});
    }
  } else {
    const radius=Math.min(width,height)*.17;
    const total=count*1.5;
    for(let i=0;i<total;i++){
      const a=Math.random()*Math.PI*2;
      const r=radius*(.45+Math.random()*.75);
      target.push({x:width/2+Math.cos(a)*r,y:height*.47+Math.sin(a)*r});
    }
  }
  while(particles.length<target.length) particles.push({x:rand(0,width),y:rand(0,height),vx:0,vy:0,r:rand(.6,2),alpha:rand(.3,.9),color:colors[Math.floor(Math.random()*colors.length)]});
  if(particles.length>target.length) particles.length=target.length;
}
function draw(now){
  ctx.clearRect(0,0,width,height);
  const active = now < burstUntil;
  for(let i=0;i<particles.length;i++){
    const p=particles[i], t=target[i];
    if(t){
      p.vx+=(t.x-p.x)*.018; p.vy+=(t.y-p.y)*.018;
    }
    p.vx*=.91; p.vy*=.91;
    if(active && Math.random()<.015){p.vx+=rand(-3,3);p.vy+=rand(-3,3)}
    p.x+=p.vx; p.y+=p.vy;
    ctx.globalAlpha=p.alpha*(.65+.35*Math.sin(now*.0015+i));
    ctx.fillStyle=p.color;
    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();
  }
  ctx.globalAlpha=1;
  requestAnimationFrame(draw);
}
heartBtn.addEventListener('click',()=>{
  mode='heart';buildTarget();burstUntil=performance.now()+850;
  heartBtn.innerHTML='Heart sent <span>♡</span>';
  setTimeout(()=>heartBtn.innerHTML='Make a heart <span>♡</span>',1400);
});
textBtn.addEventListener('click',()=>{
  secret.hidden=!secret.hidden;
  textBtn.textContent=secret.hidden?'Show message':'Hide message';
});
photoInput.addEventListener('change',()=>{
  const file=photoInput.files && photoInput.files[0];
  if(!file) return;
  if(!file.type.startsWith('image/')) return;
  const reader=new FileReader();
  reader.onload=()=>{photo.src=reader.result;photoFrame.hidden=false;};
  reader.readAsDataURL(file);
});
removePhoto.addEventListener('click',()=>{photoFrame.hidden=true;photo.src='';photoInput.value='';});
window.addEventListener('resize',resize);
resize();
requestAnimationFrame(draw);
