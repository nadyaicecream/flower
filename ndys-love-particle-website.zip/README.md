# A Little Love — Particle Heart Website

Website mini dengan animasi partikel berbentuk hati, teks “I LOVE YOU”, pesan tersembunyi, dan opsi menambahkan foto dari perangkat.

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser, atau unggah semua file ke repository GitHub.
3. Untuk GitHub Pages: buka repository → Settings → Pages → pilih `Deploy from a branch` → branch `main` dan folder `/ (root)` → Save.

## Cara mengubah tulisan
- Buka `index.html`, ubah teks di `I LOVE YOU` dan bagian subtitle.
- Buka `script.js` jika ingin mengubah perilaku animasi.
- Buka `style.css` untuk mengubah warna, font, dan tampilan.

Catatan: Google Fonts memerlukan koneksi internet. Fitur foto hanya membaca gambar yang dipilih secara lokal di browser.
